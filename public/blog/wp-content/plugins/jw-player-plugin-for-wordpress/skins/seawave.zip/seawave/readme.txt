SeaWave for LongTailVideo.com
Credits: http://www.yvoschaap.com