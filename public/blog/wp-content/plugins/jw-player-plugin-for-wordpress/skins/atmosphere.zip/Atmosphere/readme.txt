atmosphere skin for JW player
Andreas Verhamme
http://www.atmosphere-musique.fr/